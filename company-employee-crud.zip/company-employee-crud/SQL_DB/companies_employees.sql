-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 25, 2022 at 07:36 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `companies_employees`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `company_name` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `first_name`, `last_name`, `email`, `phone`, `company_name`, `avatar`, `created_at`, `updated_at`) VALUES
(1, 'Kaseem', 'Ahmad', 'kaseem@gmail.com', '1234567890', 'Technical CRUD LTD, INDIA', '1671996074.png', '2022-12-25 03:58:38', '2022-12-25 13:51:14'),
(2, 'Aliya', 'Ansari', 'aliya@gmail.com', '1234567890', 'NUS PVT LTD DELHI', '1671996344.jfif', '2022-12-25 03:59:43', '2022-12-25 13:55:44'),
(3, 'Hamza', 'Ansari', 'hamza@gmail.com', '9876543211', 'Tech PVT LTD INDIA', '1671996318.jfif', '2022-12-25 04:01:12', '2022-12-25 13:55:18'),
(4, 'XY', 'Z', 'x@gmail.com', '0987654321', 'XYZ PVT LTD INDIA', '1671996291.jfif', NULL, '2022-12-25 13:54:51'),
(5, 'Test', 'lion', 'test@gmail.com', '2147483647', 'Port LTD DELHI.', '1671996251.jfif', '2022-12-25 10:15:15', '2022-12-25 13:54:11'),
(6, 'hr', 'band', 'hr@gmail.copm', '1234567890', 'hr pvt ltd, DELHI', '1671996221.jfif', '2022-12-25 10:23:17', '2022-12-25 13:53:41'),
(7, 'OOP\'s', 'Okay', 'oka@gmail.com', '1234567890', 'Okay PVT LTD, INDIA', '1671996197.jfif', '2022-12-25 10:23:46', '2022-12-25 13:53:17'),
(8, 'ABC', 'XYZ', 'abc@gmail.com', '1234567890', 'ABC PVT LTD, India', '1671996151.jfif', '2022-12-25 10:24:17', '2022-12-25 13:52:31'),
(9, 'Sam', 'Admad', 'adma@gmail.com', '1234567890', 'Adam Pvt Ltd, INDIA', '1671996017.png', '2022-12-25 10:26:32', '2022-12-25 13:50:17'),
(10, 'WWW', 'OKAY', 'w@gmail.com', '1234567890', 'WWW Pvt Ltd, India', '1671995962.png', '2022-12-25 10:26:58', '2022-12-25 13:49:22'),
(11, 'Test', 'Testing', 'test@gmail.com', '0987654321', 'Testing PVT LTD, INDIA', '1671996432.avif', NULL, '2022-12-25 13:57:12'),
(12, 'Alu', 'Sam', 'as@gmail.com', '0987654321', 'ER PVT LTD, INDIA', '1671995808.jfif', '2022-12-25 10:28:30', '2022-12-25 13:46:48'),
(13, 'Human', 'Test', 'human@gmail.com', '1234567890', 'Human tech Pvt Ltd, India', '1671995774.png', '2022-12-25 10:40:51', '2022-12-25 13:46:14'),
(14, 'Ansari', 'Ahmad', 'ansari@gmail.com', '1234567890', 'Tech ltd, India', '1671995739.png', '2022-12-25 10:49:43', '2022-12-25 13:45:39'),
(15, 'Okay', 'Test', 'ok@gmail.com', '9090909011', 'PP Okay Ltd, Pune', '1671995705.jfif', '2022-12-25 12:14:12', '2022-12-25 13:45:05'),
(16, 'Keppy', 'Ommi', 'keppy@gmail.com', '1234567890', 'KEPPY PVT LTD , GuJRAT INDIA', '1671996511.jfif', NULL, '2022-12-25 13:58:31'),
(17, 'Papu', 'Tech', 'tech@gmail.com', '0987654321', 'PAPU Tech PVT LTD MUMBAI', '1671995900.jfif', '2022-12-25 13:48:20', '2022-12-25 13:48:20');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(17, '2014_10_12_000000_create_users_table', 1),
(18, '2014_10_12_100000_create_password_resets_table', 1),
(19, '2019_08_19_000000_create_failed_jobs_table', 1),
(20, '2022_12_25_090858_create_employees_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Kaseem Ahmad', 'kaseem@gmail.com', NULL, '$2y$10$bN3xJr/TKRv1dErI/2xH5OvNvjWXc.FTwyMNvlOV6LMM9tNRZ7/RG', NULL, '2022-12-25 13:41:27', '2022-12-25 13:41:27'),
(2, 'Test', 'test@gmail.com', NULL, '$2y$10$B9z5PKrPJjpEHz1I.oV4OuPyQJ/Yp/Wi.6pPg.A3POhlCDmn3EQ52', NULL, '2022-12-25 14:05:39', '2022-12-25 14:05:39');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
